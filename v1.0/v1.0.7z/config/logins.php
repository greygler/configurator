<?
/* * * * * * * * * * * * * * * * * * * * * * * 
 *       Password for configuration:         *
 *                  zakazy                   *
 *   Last edition by 29.09.2016, 11:22:30    *
 * * * * * * * * * * * * * * * * * * * * * * */

$login = 'admin';
$password = '21232f297a57a5a743894a0e4a801fc3';

/* * * * * * * * * * * * * * * * * * * * * * * 
 *           Created by ConfigLand           *
 *          Powered by Igor Sayutin          *
 *          http://it-senior.pp.ua           *
 * * * * * * * * * * * * * * * * * * * * * * */

?>
