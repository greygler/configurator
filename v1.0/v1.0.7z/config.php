<?
/* * * * * * * * * * * * * * * * * * * * * * * 
 *      Configuration for LandingPage:       *
 *               configurator                *
 *   Last edition by 23.04.2017, 03:57:32    *
 * * * * * * * * * * * * * * * * * * * * * * */

$valuta = 'грн';
$price_new = '100';
$skidka = '50';
$head_index = '';
$head_thanks = '';
$body_index = '';
$body_thanks = '';
$product = 'Наименование продукта';
$email = 'Ваш_email';
$comment = '';
$price_old = floor(($price_new/(100-$skidka))*100);

/* * * * * * * * * * * * * * * * * * * * * * * 
 *           Created by ConfigLand           *
 *          Powered by Igor Sayutin          *
 *          http://it-senior.pp.ua           *
 * * * * * * * * * * * * * * * * * * * * * * */

?>
